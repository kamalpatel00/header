import React, { Component } from "react";

class Contact extends Component {
  render() {
    return <div>You are calling to Bettr Service provider</div>;
  }
}

export default Contact;
